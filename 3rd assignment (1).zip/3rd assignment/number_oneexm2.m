clear all; close all; clc;
%DETERMINATION OF ROOTS OF EQUATUIONS USING BISECTION METHODE
disp('BISECTION METHODE EXAMPLE TWO');
f= @(X) 0.2*X + 30*sin(0.1*X)-100;
tic;
a=502;
b=503;
tol=1e-6;
if f(a)*f(b)>0
    disp('choose different intervals');
end
while (b-a)/2>tol
    c=(a+b)/2;
    if f(c)==0
        break;
   
    elseif f(c)*f(a)<0
        b=c;
    else
        a=c;
    end
end
fprintf('Approximate root = %.6f KWh\n',c);
t1=toc;

   
%inputs
disp('SECANT METHODE EXAMPLE 2');
f=@(x) 0.2*x + 30*sin(0.1*x)-100;
tol=1e-6;
tic;
x0=502;
x1=503;
n=inf;
df=(f(x1)-f(x0))/(x1-x0);
%processing
if df~=0
    for i=1:n
        x2=x1-f(x1)/df;
        fprintf('x%d = %.6f\n',i,x2);
        if abs(x2-x1)<tol
            break
        end
        x1=x2;
    end
else
    disp('Secant method cannot be applied');
end
fprintf('The root is %.6f KWh\n',x2);
t2=toc;      


%this code will help to solve all nrm problems
%inputs
disp('NRM METHODE EXAMPLE 2');
f=@(x) 0.2*x +30*sin(0.1*x)-100;
df=@(x) x +3*cos(0.1*x);
tol=1e-6;
tic;
x0=500;
n=inf;
% processing
if df(x0)~=0
    for k=1:n
        x1=x0-f(x0)/df(x0);
        fprintf('x%d= %.6f\n',k,x1);
        %tolerance test
        if abs(x1-x0)<tol
            break
        end
       x0=x1;

        
    end
else
    disp('Newton Rampthon Failed');
end
fprintf('The root is %.6f KWh\n',x1);
t3=toc;
methodes={'Bisection','Secant Methode','Newton Rapson Methode'};
time=[t1,t2,t3];
figure;
bar(categorical(methodes),time,'r');
xlabel('methodes');
ylabel('Time taken');
title('A bar graph showing time taken by the different methodes');
grid on;











